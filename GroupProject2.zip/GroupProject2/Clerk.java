package GroupProject2;

public class Clerk extends Staff
{
    // instance variables - replace the example below with your own

    public Clerk()
    {
        
    }

    
}
